from django.contrib import admin
from .models import Post,User


class PostAdmin(admin.ModelAdmin):
    list_display = ["title","body","Created_by"]
admin.site.register(Post)







