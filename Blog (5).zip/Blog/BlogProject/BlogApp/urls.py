"""
URL configuration for BlogProject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
     path('create-post/', views.create_post, name='create-post'),
     path('post-details/<int:pk>/', views.post_details, name='post-details'),
     path('update-post/<int:pk>/', views.update_post, name='update-post'),
     path('delete-post/<int:pk>/', views.delete_post, name='delete-post'),
     path('all-created-post/', views.all_created_post, name='all-created-post'),
     path('', views.all_post, name='home'),
     path('search/', views.search, name='search'),
     
     
     
]

