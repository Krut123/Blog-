from django.shortcuts import render,redirect,HttpResponse
from django.contrib import messages
from .form import CreatePostForm, UpdatePostForm
from .models import Post


#create post
""" def create_post(request):
    if request.method == 'POST':
        form = CreatePostForm(request.POST)
        if form.is_valid():
            var = form.save(commit = False)
            var.created_by = request.user
            var.save()
            if var.is_published:
                messages.info(request,'New Post Created')
                return redirect('home')
            else:
                messages.warning(request,'New Post Created But Not Published')
                return redirect('all-created-posts')
        else:
            messages.warning(request,'something went wrong')
            return redirect('create-post')
    else:
        form = CreatePostForm()
    context = {'form':form}
    return render(request,'post/create_post.html',context) """



def create_post(request):
    if request.method == 'POST':
        form = CreatePostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.Created_by = request.user  # Assign the current user to the Created_by field
            post.save()
            if post.is_published:
                messages.info(request, 'New Post Created')
                return redirect('home')
            else:
                messages.warning(request, 'New Post Created But Not Published')
                return redirect('all-created-posts')
        else:
            messages.warning(request, 'Something went wrong')
            return redirect('create-post')
    else:
        form = CreatePostForm()
    return render(request, 'post/create_post.html',{'form':form})


#view post details

def post_details(request,pk):
    post = Post.objects.get(pk=pk)
    context = {'post':post}
    return render(request,'post/post_details.html',context)

#update post
def update_post(request,pk):
    post = Post.objects.get(pk=pk)
    if request.method == 'POST':
        form = UpdatePostForm(request.POST,instance=post)
        if form.is_valid():
            form.save()
            messages.info(request,'post has been updated')
            return redirect('home')
        else:
            messages.warning(request,'error')
            #return redirect('')
    else:
        form = UpdatePostForm(instance=post)
    context = {'form':form, 'post':post}
    return render(request,'post/update_post.html',context)


#delete post

def delete_post(request,pk):
    post = Post.objects.get(pk=pk)
    post.delete()
    return redirect('home')

#see all post

def all_created_post(request):
    posts = Post.objects.filter(Created_by = request.user)
    context = {'posts':posts}
    return render(request,'post/all_created_post.html',context)


#view all post

def all_post(request):
    posts = Post.objects.filter(is_published = True)
    context = {'posts':posts}
    return render(request,'post/all_post.html',context)
 

def search(request):
    query = request.GET['query']
    post = Post.objects.all()
    qs = post.filter(title__icontains=query) 
    return render(request,"post/search.html",{"posts":qs,"query":query})


""" def like(request,id):
    currentPost = Post.objects.get(id=id)
    currentUser = request.user

    for i in currentPost.like.all():
        if i == currentUser:
            currentPost.like.remove(currentUser)
            break
        else:
            for i in currentPost.dislike.all():
                if i == currentUser:
                    currentPost.dislike.remove(currentUser)
                    break
                else:
                    currentPost.like.add(currentUser)

    return redirect('home')



def dislike(request,id):
    currentPost = Post.objects.get(id=id)
    currentUser = request.user

    for i in currentPost.dislike.all():
        if i == currentUser:
            currentPost.dislike.remove(currentUser)
            break
        else:
            for i in currentPost.dislike.all():
                if i == currentUser:
                    currentPost.like.remove(currentUser)
                    break
                else:
                    currentPost.dislike.add(currentUser)

    return redirect('home')
             """












                                    








    












